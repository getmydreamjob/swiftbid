import { config } from 'dotenv';
config();

import '@/ai/flows/match-contractors.ts';
import '@/ai/flows/analyze-house-plans.ts';