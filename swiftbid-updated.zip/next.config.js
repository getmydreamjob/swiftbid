/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    allowedDevOrigins: [
      "https://9003-firebase-studio-1747257705164.cluster-pgviq6mvsncnqxx6kr7pbz65v6.cloudworkstations.dev"
    ]
  }
};
module.exports = nextConfig;
